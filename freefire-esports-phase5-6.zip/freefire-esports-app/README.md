# Free Fire Esports Tournament App

Real-money-adjacent esports tournament platform for Free Fire — Android app,
NestJS backend, React admin panel. Built in phases; see phase status below.

## ⚠️ Read before Phase 5 / Phase 9

Your current wallet design (coins bought with real ₹, entry fees, cash
withdrawal to UPI) is very close to what India's Promotion and Regulation of
Online Gaming Act, 2025 (in force 1 May 2026) restricts for real-money games.
Get an Indian gaming/tech lawyer to confirm your setup before wiring up real
UPI payments (Phase 5) or withdrawals (Phase 9). Everything else is unaffected.

## Project structure

```
/backend    NestJS + Prisma + PostgreSQL — the only thing with money authority
/android    Kotlin + Jetpack Compose — scaffolded starting Phase 2
/admin      React admin dashboard — scaffolded starting Phase 7
/docs       Setup guides, API notes
```

## Phase status

- [x] Phase 1 — Architecture + stack + database
- [x] Phase 2 — Authentication + profile
- [x] **Phase 3 — Tournament system** (this delivery)
- [x] **Phase 4 — Wallet + ledger** (this delivery)
- [x] **Phase 5 — UPI payment-request system** (this delivery)
- [x] **Phase 6 — Redeem-code system** (this delivery)
- [ ] Phase 7 — Admin panel
- [ ] Phase 8 — Results + prizes
- [ ] Phase 9 — Withdrawals
- [ ] Phase 10 — Notifications + support
- [ ] Phase 11 — Security hardening
- [ ] Phase 12 — Testing
- [ ] Phase 13 — Android build/release

## What's included so far

**Phase 1** — Database schema (19 models), a minimal NestJS server with a
`/health` endpoint proving the server boots and the DB connection works.

**Phase 2** — Firebase-backed auth (Google Sign-In + Phone/OTP) on both
sides:
- Backend: `FirebaseAuthGuard` verifies tokens on every protected route
  and auto-provisions User + Profile + Wallet on first login; `GET/PUT
  /profile` for reading and updating profile data.
- Android: a real (not mocked) Kotlin + Jetpack Compose app — login screen,
  phone/OTP flow, profile setup screen wired to the live backend, both
  premium themes defined and ready to switch between.

**Phase 3 + 4** — Tournaments and the wallet ledger, wired together:
- Backend: `WalletService` is the only code path allowed to change a
  balance (atomic, row-locked, idempotent). `TournamentService` handles
  listing, team creation/joining, and one shared registration path that
  atomically deducts the entry fee (via WalletService), fills a slot, and
  creates the registration — solo and team formats both funnel through it.
- Android: real Home screen (tournament list + wallet chip), tournament
  detail, team creation/join/roster screen, and a wallet screen showing
  balance + transaction history.

**Phase 5 + 6** — Add Coins (UPI) and Redeem Codes, both admin-approved:
- Backend: `SettingsService` (UPI ID / coin rate — admin-editable, not
  hard-coded), `PaymentRequestService` and `RedeemService`, each with a
  user-facing create/track path and an admin approve/reject path that
  credits coins through `WalletService`. Admin routes are protected by a
  **provisional** `AdminRoleGuard` (checks `User.role === ADMIN`) — Phase
  7 replaces this with the fully separate AdminUser login the project's
  own rules call for.
- Android: Add Coins screen with a real UPI QR code + deep-link "Pay via
  UPI app" button (amount fixed, not editable in-app) and UTR submission;
  Redeem Code screen with status tracking.

No admin panel UI yet (Phase 7) — `docs/PHASE3_4_SETUP.md` and
`docs/PHASE5_6_SETUP.md` cover testing via Prisma Studio and curl in the
meantime.

See `docs/SETUP.md` (Phase 1), `docs/PHASE2_SETUP.md` (Phase 2),
`docs/PHASE3_4_SETUP.md` (Phase 3+4), and `docs/PHASE5_6_SETUP.md`
(Phase 5+6) for exact setup steps.
