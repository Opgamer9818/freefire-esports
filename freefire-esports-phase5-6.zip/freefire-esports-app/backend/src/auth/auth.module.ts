import { Module } from '@nestjs/common';
import { FirebaseAuthGuard } from './firebase-auth.guard';
import { AdminRoleGuard } from './admin-role.guard';

@Module({
  providers: [FirebaseAuthGuard, AdminRoleGuard],
  exports: [FirebaseAuthGuard, AdminRoleGuard],
})
export class AuthModule {}
