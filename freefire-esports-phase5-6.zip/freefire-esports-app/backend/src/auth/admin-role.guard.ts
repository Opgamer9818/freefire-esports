import { CanActivate, ExecutionContext, ForbiddenException, Injectable } from '@nestjs/common';

// PROVISIONAL. The project's own security rules call for admin auth to be
// completely separate from user login (separate AdminUser table, its own
// username/password) — that's built in Phase 7.
//
// Until then, this guard is a real backend check (not a hidden UI trick)
// gating a handful of admin routes so payment/redeem approval is testable
// starting now: it requires a valid Firebase-authenticated user whose
// User.role is ADMIN. Set your own row's role to ADMIN via Prisma Studio
// to test these routes locally.
//
// Always combine with FirebaseAuthGuard, which is what actually populates
// request.user: @UseGuards(FirebaseAuthGuard, AdminRoleGuard)
@Injectable()
export class AdminRoleGuard implements CanActivate {
  canActivate(context: ExecutionContext): boolean {
    const request = context.switchToHttp().getRequest();
    const user = request.user;
    if (!user || user.role !== 'ADMIN') {
      throw new ForbiddenException('Admin access required');
    }
    return true;
  }
}
