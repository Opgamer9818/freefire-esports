import { BadRequestException, Injectable, NotFoundException } from '@nestjs/common';
import { createHash } from 'crypto';
import { PrismaService } from '../prisma/prisma.service';
import { WalletService } from '../wallet/wallet.service';

@Injectable()
export class RedeemService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly walletService: WalletService,
  ) {}

  private normalize(code: string) {
    return code.trim().toUpperCase();
  }

  private hash(normalizedCode: string) {
    return createHash('sha256').update(normalizedCode).digest('hex');
  }

  async submitCode(userId: string, rawCode: string) {
    const normalized = this.normalize(rawCode);
    const codeHash = this.hash(normalized);

    const existing = await this.prisma.redeemRequest.findUnique({ where: { codeHash } });
    if (existing) {
      throw new BadRequestException('This code has already been submitted');
    }

    return this.prisma.redeemRequest.create({
      data: { userId, code: normalized, codeHash, status: 'PENDING' },
    });
  }

  async myRequests(userId: string) {
    return this.prisma.redeemRequest.findMany({
      where: { userId },
      orderBy: { createdAt: 'desc' },
      // Never send the raw code back to any client, including the
      // submitter, once it's stored — nothing needs to display it again.
      select: {
        id: true,
        status: true,
        approvedCoins: true,
        adminNote: true,
        createdAt: true,
        resolvedAt: true,
      },
    });
  }

  // ---------------- Admin ----------------

  async listPending() {
    return this.prisma.redeemRequest.findMany({
      where: { status: 'PENDING' },
      orderBy: { createdAt: 'asc' },
      include: { user: { include: { profile: true } } },
    });
  }

  async approve(requestId: string, adminId: string, approvedCoins: number, note?: string) {
    return this.prisma.$transaction(async (tx) => {
      const req = await tx.redeemRequest.findUnique({ where: { id: requestId } });
      if (!req) throw new NotFoundException('Redeem request not found');
      if (req.status !== 'PENDING') throw new BadRequestException('This request was already resolved');

      await this.walletService.credit(
        {
          userId: req.userId,
          type: 'REDEEM_CREDIT',
          amount: approvedCoins,
          idempotencyKey: `redeem-approve:${req.id}`,
          reference: req.id,
          description: 'Redeem code approved',
          createdByAdminId: adminId,
        },
        tx,
      );

      return tx.redeemRequest.update({
        where: { id: requestId },
        data: { status: 'APPROVED', approvedCoins, adminId, adminNote: note, resolvedAt: new Date() },
      });
    });
  }

  async reject(requestId: string, adminId: string, note?: string) {
    const req = await this.prisma.redeemRequest.findUnique({ where: { id: requestId } });
    if (!req) throw new NotFoundException('Redeem request not found');
    if (req.status !== 'PENDING') throw new BadRequestException('This request was already resolved');

    return this.prisma.redeemRequest.update({
      where: { id: requestId },
      data: { status: 'REJECTED', adminId, adminNote: note, resolvedAt: new Date() },
    });
  }
}
