import { Body, Controller, Get, Param, Post, UseGuards } from '@nestjs/common';
import { User } from '@prisma/client';
import { FirebaseAuthGuard } from '../auth/firebase-auth.guard';
import { AdminRoleGuard } from '../auth/admin-role.guard';
import { CurrentUser } from '../auth/current-user.decorator';
import { RedeemService } from './redeem.service';
import { ApproveRedeemDto } from './dto/approve-redeem.dto';
import { ResolveRequestDto } from '../payment/dto/resolve-request.dto';

@UseGuards(FirebaseAuthGuard, AdminRoleGuard)
@Controller('admin/redeem-requests')
export class AdminRedeemController {
  constructor(private readonly service: RedeemService) {}

  @Get()
  listPending() {
    return this.service.listPending();
  }

  @Post(':id/approve')
  approve(@Param('id') id: string, @CurrentUser() admin: User, @Body() dto: ApproveRedeemDto) {
    return this.service.approve(id, admin.id, dto.approvedCoins, dto.note);
  }

  @Post(':id/reject')
  reject(@Param('id') id: string, @CurrentUser() admin: User, @Body() dto: ResolveRequestDto) {
    return this.service.reject(id, admin.id, dto.note);
  }
}
