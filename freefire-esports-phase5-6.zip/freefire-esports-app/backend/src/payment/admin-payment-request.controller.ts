import { Body, Controller, Get, Param, Post, UseGuards } from '@nestjs/common';
import { User } from '@prisma/client';
import { FirebaseAuthGuard } from '../auth/firebase-auth.guard';
import { AdminRoleGuard } from '../auth/admin-role.guard';
import { CurrentUser } from '../auth/current-user.decorator';
import { PaymentRequestService } from './payment-request.service';
import { ResolveRequestDto } from './dto/resolve-request.dto';

@UseGuards(FirebaseAuthGuard, AdminRoleGuard)
@Controller('admin/payment-requests')
export class AdminPaymentRequestController {
  constructor(private readonly service: PaymentRequestService) {}

  @Get()
  listPending() {
    return this.service.listPending();
  }

  @Post(':id/approve')
  approve(@Param('id') id: string, @CurrentUser() admin: User, @Body() dto: ResolveRequestDto) {
    return this.service.approve(id, admin.id, dto.note);
  }

  @Post(':id/reject')
  reject(@Param('id') id: string, @CurrentUser() admin: User, @Body() dto: ResolveRequestDto) {
    return this.service.reject(id, admin.id, dto.note);
  }
}
