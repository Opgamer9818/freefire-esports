# Free Fire Esports Tournament App

Real-money-adjacent esports tournament platform for Free Fire — Android app,
NestJS backend, React admin panel. Built in phases; see phase status below.

## ⚠️ Read before Phase 5 / Phase 9

Your current wallet design (coins bought with real ₹, entry fees, cash
withdrawal to UPI) is very close to what India's Promotion and Regulation of
Online Gaming Act, 2025 (in force 1 May 2026) restricts for real-money games.
Get an Indian gaming/tech lawyer to confirm your setup before wiring up real
UPI payments (Phase 5) or withdrawals (Phase 9). Everything else is unaffected.

## Project structure

```
/backend    NestJS + Prisma + PostgreSQL — the only thing with money authority
/android    Kotlin + Jetpack Compose — scaffolded starting Phase 2
/admin      React admin dashboard — scaffolded starting Phase 7
/docs       Setup guides, API notes
```

## Phase status

- [x] **Phase 1 — Architecture + stack + database** (this delivery)
- [ ] Phase 2 — Authentication + profile
- [ ] Phase 3 — Tournament system
- [ ] Phase 4 — Wallet + ledger
- [ ] Phase 5 — UPI payment-request system
- [ ] Phase 6 — Redeem-code system
- [ ] Phase 7 — Admin panel
- [ ] Phase 8 — Results + prizes
- [ ] Phase 9 — Withdrawals
- [ ] Phase 10 — Notifications + support
- [ ] Phase 11 — Security hardening
- [ ] Phase 12 — Testing
- [ ] Phase 13 — Android build/release

## What Phase 1 includes

- Complete database schema (`backend/prisma/schema.prisma`) — 19 models
  covering users, profiles, teams, tournaments, registrations, results,
  wallets, the wallet ledger, payment requests, redeem requests,
  withdrawals, admin users, audit logs, bans, support tickets, app
  settings, notifications, and leaderboard entries.
- A minimal, runnable NestJS server with a `/health` endpoint that proves
  the server boots and the database connection + schema both work.
- No business logic yet (no auth, no tournament join, no wallet
  operations) — that starts in Phase 2. This phase is purely the
  foundation everything else gets built on.

See `docs/SETUP.md` for exact setup steps.
