# Android App

Empty for now on purpose.

The Kotlin + Jetpack Compose Android Studio project gets scaffolded here in
**Phase 2 (Authentication + profile)**, once there's a backend running to
actually log in against. Building it earlier would just mean throwing away
screens once auth is wired in.
