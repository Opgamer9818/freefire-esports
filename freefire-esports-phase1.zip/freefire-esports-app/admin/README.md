# Admin Panel

Empty for now on purpose.

The React admin dashboard gets scaffolded here in **Phase 7 (Admin panel)**,
once there are real payment/redeem/withdrawal/tournament endpoints for it to
call. It'll be a separate app from the user-facing Android app, calling the
same backend with an admin-only login.
