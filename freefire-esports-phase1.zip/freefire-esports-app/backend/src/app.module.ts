import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { ThrottlerModule } from '@nestjs/throttler';
import { PrismaModule } from './prisma/prisma.module';
import { AppController } from './app.controller';
import { AppService } from './app.service';

@Module({
  imports: [
    ConfigModule.forRoot({ isGlobal: true }),
    ThrottlerModule.forRoot([{ ttl: 60000, limit: 100 }]),
    PrismaModule,

    // Added in later phases — do not implement early, keeps each
    // phase reviewable on its own:
    // Phase 2: AuthModule, ProfileModule
    // Phase 3: TournamentModule, TeamModule
    // Phase 4: WalletModule
    // Phase 5: PaymentRequestModule
    // Phase 6: RedeemModule
    // Phase 7: AdminModule
    // Phase 8: ResultModule
    // Phase 9: WithdrawalModule
    // Phase 10: NotificationModule, SupportModule
  ],
  controllers: [AppController],
  providers: [AppService],
})
export class AppModule {}
