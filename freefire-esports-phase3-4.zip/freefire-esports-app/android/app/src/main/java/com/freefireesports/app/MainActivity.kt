package com.freefireesports.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import com.freefireesports.app.navigation.NavGraph
import com.freefireesports.app.ui.theme.AppTheme
import com.freefireesports.app.ui.theme.FreeFireEsportsTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            // Phase 2 always opens on Black+Gold. From Phase 3 onward, once
            // there's a Settings screen, this reads the saved
            // profile.themePreference instead of a hardcoded default.
            FreeFireEsportsTheme(appTheme = AppTheme.BLACK_GOLD) {
                Surface(modifier = Modifier.fillMaxSize()) {
                    NavGraph()
                }
            }
        }
    }
}
