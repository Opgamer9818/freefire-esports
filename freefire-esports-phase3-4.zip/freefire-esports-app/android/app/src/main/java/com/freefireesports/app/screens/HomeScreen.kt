package com.freefireesports.app.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Card
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.freefireesports.app.tournament.TournamentListUiState
import com.freefireesports.app.tournament.TournamentListViewModel
import com.freefireesports.app.wallet.WalletUiState
import com.freefireesports.app.wallet.WalletViewModel

@Composable
fun HomeScreen(
    onOpenTournament: (String) -> Unit,
    onOpenWallet: () -> Unit,
    onSignOut: () -> Unit,
    tournamentViewModel: TournamentListViewModel = viewModel(),
    walletViewModel: WalletViewModel = viewModel(),
) {
    val uiState by tournamentViewModel.uiState.collectAsState()
    val walletState by walletViewModel.uiState.collectAsState()

    LaunchedEffect(Unit) {
        tournamentViewModel.load()
        walletViewModel.load()
    }

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text("Free Fire Esports", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            TextButton(onClick = onSignOut) { Text("Sign out") }
        }

        Spacer(modifier = Modifier.height(12.dp))

        Card(onClick = onOpenWallet, modifier = Modifier.fillMaxWidth()) {
            Row(
                modifier = Modifier.fillMaxWidth().padding(16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text("Wallet balance")
                val balance = (walletState as? WalletUiState.Loaded)?.wallet?.availableBalance
                Text(if (balance != null) "$balance coins" else "…", fontWeight = FontWeight.Bold)
            }
        }

        Spacer(modifier = Modifier.height(20.dp))
        Text("Tournaments", style = MaterialTheme.typography.titleMedium)
        Spacer(modifier = Modifier.height(8.dp))

        when (val state = uiState) {
            is TournamentListUiState.Loading -> CircularProgressIndicator()
            is TournamentListUiState.Error -> Text(state.message, color = MaterialTheme.colorScheme.error)
            is TournamentListUiState.Loaded -> {
                if (state.tournaments.isEmpty()) {
                    Text("No upcoming tournaments right now.")
                } else {
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(state.tournaments) { t ->
                            Card(onClick = { onOpenTournament(t.id) }, modifier = Modifier.fillMaxWidth()) {
                                Column(modifier = Modifier.padding(16.dp)) {
                                    Text(t.name, fontWeight = FontWeight.Bold)
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        "${t.format} · ${if (t.isFree) "Free" else "${t.entryFeeCoins} coins"} · " +
                                            "${t.slotsFilled}/${t.slots} slots",
                                        style = MaterialTheme.typography.bodySmall,
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
