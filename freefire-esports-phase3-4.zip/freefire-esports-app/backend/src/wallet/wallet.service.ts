import { Injectable, BadRequestException } from '@nestjs/common';
import { Prisma, WalletTxnType } from '@prisma/client';
import { PrismaService } from '../prisma/prisma.service';

interface LedgerInput {
  userId: string;
  type: WalletTxnType;
  amount: number; // always positive here — credit()/debit() apply the sign
  idempotencyKey: string;
  reference?: string;
  description?: string;
  createdByAdminId?: string;
}

type Db = PrismaService | Prisma.TransactionClient;

@Injectable()
export class WalletService {
  constructor(private readonly prisma: PrismaService) {}

  // The ONLY method in the whole codebase allowed to change a wallet
  // balance. Coin purchases, entry fees, prizes, refunds, redeem credits,
  // withdrawal reserve/debit/reversal, admin adjustments — all of them
  // funnel through here. Pass `tx` when this needs to happen atomically
  // alongside other writes (e.g. tournament registration).
  async credit(input: LedgerInput, tx?: Prisma.TransactionClient) {
    return this.write({ ...input, amount: Math.abs(input.amount) }, tx);
  }

  async debit(input: LedgerInput, tx?: Prisma.TransactionClient) {
    return this.write({ ...input, amount: -Math.abs(input.amount) }, tx);
  }

  private async write(input: LedgerInput, tx?: Prisma.TransactionClient) {
    const run = async (db: Prisma.TransactionClient) => {
      // Idempotency: if this exact operation already happened, return the
      // existing record instead of processing it again.
      const existing = await db.walletTransaction.findUnique({
        where: { idempotencyKey: input.idempotencyKey },
      });
      if (existing) return existing;

      // Row lock so two concurrent calls for the same user can't both
      // read the same stale balance and both "succeed".
      const locked = await db.$queryRaw<{ availableBalance: number }[]>`
        SELECT "availableBalance" FROM "Wallet" WHERE "userId" = ${input.userId} FOR UPDATE
      `;
      if (!locked[0]) throw new BadRequestException('Wallet not found for user');

      const newBalance = locked[0].availableBalance + input.amount;
      if (newBalance < 0) throw new BadRequestException('Insufficient balance');

      await db.wallet.update({
        where: { userId: input.userId },
        data: { availableBalance: newBalance },
      });

      try {
        return await db.walletTransaction.create({
          data: {
            userId: input.userId,
            type: input.type,
            amount: input.amount,
            balanceAfter: newBalance,
            idempotencyKey: input.idempotencyKey,
            reference: input.reference,
            description: input.description,
            createdByAdminId: input.createdByAdminId,
          },
        });
      } catch (e) {
        // Lost a race with a concurrent identical request — treat as
        // already-done rather than crash.
        if (e instanceof Prisma.PrismaClientKnownRequestError && e.code === 'P2002') {
          return db.walletTransaction.findUniqueOrThrow({ where: { idempotencyKey: input.idempotencyKey } });
        }
        throw e;
      }
    };

    if (tx) return run(tx);
    return this.prisma.$transaction((client) => run(client));
  }

  async getBalance(userId: string) {
    return this.prisma.wallet.findUniqueOrThrow({ where: { userId } });
  }

  async getTransactions(userId: string, limit = 50) {
    return this.prisma.walletTransaction.findMany({
      where: { userId },
      orderBy: { createdAt: 'desc' },
      take: limit,
    });
  }
}
