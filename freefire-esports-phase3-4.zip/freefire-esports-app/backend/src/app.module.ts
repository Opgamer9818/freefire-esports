import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { ThrottlerModule } from '@nestjs/throttler';
import { PrismaModule } from './prisma/prisma.module';
import { AuthModule } from './auth/auth.module';
import { ProfileModule } from './profile/profile.module';
import { WalletModule } from './wallet/wallet.module';
import { TournamentModule } from './tournament/tournament.module';
import { AppController } from './app.controller';
import { AppService } from './app.service';

@Module({
  imports: [
    ConfigModule.forRoot({ isGlobal: true }),
    ThrottlerModule.forRoot([{ ttl: 60000, limit: 100 }]),
    PrismaModule,
    AuthModule,
    ProfileModule,
    WalletModule,
    TournamentModule,

    // Added in later phases — do not implement early, keeps each
    // phase reviewable on its own:
    // Phase 5: PaymentRequestModule
    // Phase 6: RedeemModule
    // Phase 7: AdminModule
    // Phase 8: ResultModule
    // Phase 9: WithdrawalModule
    // Phase 10: NotificationModule, SupportModule
  ],
  controllers: [AppController],
  providers: [AppService],
})
export class AppModule {}
