import { Body, Controller, Get, Put, UseGuards } from '@nestjs/common';
import { AdminUser } from '@prisma/client';
import { AdminJwtGuard } from './admin-jwt.guard';
import { CurrentAdmin } from './current-admin.decorator';
import { SettingsService } from '../settings/settings.service';

const MANAGED_KEYS = ['upi_id', 'upi_payee_name', 'coin_rate_inr', 'min_withdrawal', 'max_withdrawal'];

@UseGuards(AdminJwtGuard)
@Controller('admin/settings')
export class AdminSettingsController {
  constructor(private readonly settings: SettingsService) {}

  @Get()
  async getAll() {
    const values = await Promise.all(MANAGED_KEYS.map((k) => this.settings.get(k)));
    return Object.fromEntries(MANAGED_KEYS.map((k, i) => [k, values[i]]));
  }

  @Put()
  async update(@Body() body: Record<string, unknown>, @CurrentAdmin() admin: AdminUser) {
    for (const key of MANAGED_KEYS) {
      if (key in body) {
        await this.settings.set(key, body[key], admin.id);
      }
    }
    return this.getAll();
  }
}
