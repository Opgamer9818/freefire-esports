import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { ThrottlerModule } from '@nestjs/throttler';
import { PrismaModule } from './prisma/prisma.module';
import { AuthModule } from './auth/auth.module';
import { ProfileModule } from './profile/profile.module';
import { WalletModule } from './wallet/wallet.module';
import { TournamentModule } from './tournament/tournament.module';
import { SettingsModule } from './settings/settings.module';
import { PaymentModule } from './payment/payment.module';
import { RedeemModule } from './redeem/redeem.module';
import { AdminModule } from './admin/admin.module';
import { WithdrawalModule } from './withdrawal/withdrawal.module';
import { NotificationModule } from './notification/notification.module';
import { SupportModule } from './support/support.module';
import { AppController } from './app.controller';
import { AppService } from './app.service';

@Module({
  imports: [
    ConfigModule.forRoot({ isGlobal: true }),
    ThrottlerModule.forRoot([{ ttl: 60000, limit: 100 }]),
    PrismaModule,
    AuthModule,
    ProfileModule,
    SettingsModule,
    NotificationModule,
    WalletModule,
    TournamentModule,
    PaymentModule,
    RedeemModule,
    AdminModule,
    WithdrawalModule,
    SupportModule,

    // Added in later phases — do not implement early, keeps each
    // phase reviewable on its own:
    // Phase 11: security hardening — no new module, tightens what's here
    // Phase 8: ResultModule
    // Phase 9: WithdrawalModule
    // Phase 10: NotificationModule, SupportModule
  ],
  controllers: [AppController],
  providers: [AppService],
})
export class AppModule {}
