package com.freefireesports.app.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

// Real Home content (featured tournament, wallet balance, etc.) arrives in
// Phase 3. This just confirms Phase 2's whole loop actually works:
// Android login -> backend token verification -> profile save/load.
@Composable
fun HomePlaceholderScreen(onSignOut: () -> Unit) {
    Column(
        modifier = Modifier.fillMaxSize().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Text("You're signed in", style = MaterialTheme.typography.headlineSmall)
        Spacer(modifier = Modifier.height(8.dp))
        Text("Tournaments, wallet, and the rest of the app arrive in the next phases.")
        Spacer(modifier = Modifier.height(32.dp))
        OutlinedButton(onClick = onSignOut) { Text("Sign out") }
    }
}
